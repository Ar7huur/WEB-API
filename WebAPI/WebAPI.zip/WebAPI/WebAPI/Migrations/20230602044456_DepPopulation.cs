﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebAPI.Migrations
{
    /// <inheritdoc />
    public partial class DepPopulation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("INSERT INTO Departamentos(Nome)" +
                "VALUES ('Computers')");
            migrationBuilder.Sql("INSERT INTO Departamentos(Nome)" +
                "VALUES ('Eletronics')");
            migrationBuilder.Sql("INSERT INTO Departamentos(Nome)" +
                "VALUES ('Fashion')");
            migrationBuilder.Sql("INSERT INTO Departamentos(Nome)" +
                "VALUES ('Books')");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DELETE FROM Departamentos");
        }
    }
}
