﻿namespace WebAPI.Models {
    public class Vendedor {

        public int VendedorID { get; set; }
        public string VendedorNome { get; set; }
        public string VendedorEmail { get; set; }
        public decimal VendedorSalario { get; set; }

        public int DepartamentoID { get; set; }
        public Departamento? Departamento { get; set; }
        


    }
}
